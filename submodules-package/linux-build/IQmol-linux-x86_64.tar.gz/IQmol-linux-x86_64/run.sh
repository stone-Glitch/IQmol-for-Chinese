#!/usr/bin/env bash
# IQmol 中文版 一键启动脚本（Linux x86_64）
#
# 作用：不安装、不污染系统，直接以本目录为根运行 IQmol。
#      自动设置：
#        - LD_LIBRARY_PATH  指向包内 lib/（Qt5/OpenBabel/OpenMesh 等 45 个库）
#        - QT_PLUGIN_PATH   指向包内 lib/plugins/
#        - BABEL_DATADIR    指向包内 share/openbabel/
#        - 资源路径（shaders/fragments/qchem_option.db）首次运行时写入 IQmol 偏好，
#          IQmol 在 Linux 下硬编码 /usr/share/iqmol，无法用环境变量覆盖，
#          故通过预写 ~/.config/iqmol.org/IQmol.conf 实现免安装运行。
#
# 用法：
#   ./run.sh                 # 启动 IQmol
#   ./run.sh 分子文件.xyz     # 启动并打开指定文件
#
set -u

# ---- 定位包根目录（本脚本所在目录，允许通过软链接调用）----
SOURCE="${BASH_SOURCE[0]}"
while [ -L "$SOURCE" ]; do
  DIR="$(cd -P "$(dirname "$SOURCE")" && pwd)"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
ROOT="$(cd -P "$(dirname "$SOURCE")" && pwd)"

BIN="$ROOT/bin/IQmol"
[ -x "$BIN" ] || { echo "ERROR: 未找到可执行文件 $BIN" >&2; exit 1; }

# ---- 运行时环境 ----
export LD_LIBRARY_PATH="$ROOT/lib:${LD_LIBRARY_PATH:-}"
export QT_PLUGIN_PATH="$ROOT/lib/plugins"
export QT_QPA_PLATFORM_PLUGIN_PATH="$ROOT/lib/plugins/platforms"
export BABEL_DATADIR="$ROOT/share/openbabel"

# ---- 资源路径注入（免安装运行的关键）----
# IQmol 在 Linux 下把资源目录硬编码为 /usr/share/iqmol，
# 但偏好文件中的键可覆盖。首次运行时把包内路径写入偏好，
# 避免要求用户 sudo 复制到系统目录。
CONF_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/iqmol.org"
CONF="$CONF_DIR/IQmol.conf"
mkdir -p "$CONF_DIR"

needs_write=0
if [ ! -f "$CONF" ]; then
  needs_write=1
else
  # 若已有配置指向其它位置，也更新为本包路径
  if ! grep -q "^ShaderDirectory=$ROOT/share/shaders" "$CONF" 2>/dev/null; then
    needs_write=1
  fi
fi

if [ "$needs_write" = "1" ]; then
  # 移除旧的同名键，再追加新值（QSettings ini 格式为 Key=Value）
  if [ -f "$CONF" ]; then
    grep -v -E "^(ShaderDirectory|FragmentDirectory|QChemDatabaseFilePath|ServerConfigurationDirectory|FavouriteDirectory)=" \
       "$CONF" > "$CONF.tmp" 2>/dev/null && mv "$CONF.tmp" "$CONF"
  fi
  # 确保 [General] 段存在
  if ! grep -q "^\[General\]" "$CONF" 2>/dev/null; then
    printf '[General]\n' >> "$CONF"
  fi
  {
    echo "ShaderDirectory=$ROOT/share/shaders"
    echo "FragmentDirectory=$ROOT/share/fragments"
    echo "QChemDatabaseFilePath=$ROOT/share/qchem_option.db"
  } >> "$CONF"
  echo "[run.sh] 已写入资源路径到 $CONF"
fi

# ---- 启动 ----
exec "$BIN" "$@"
